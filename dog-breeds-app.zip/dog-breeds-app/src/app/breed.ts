export interface Breed {
  name: string;
  image: string;
}