import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs'; // <-- Import forkJoin
import { switchMap, map } from 'rxjs/operators'; // <-- Import switchMap and map

@Injectable({
  providedIn: 'root'
})
export class DogBreedsService {
  private apiUrl = 'https://dog.ceo/api';

  constructor(private http: HttpClient) {}

  getAllBreeds(): Observable<any> {
    return this.http.get(`${this.apiUrl}/breeds/list/all`);
  }

  getBreedImage(breedName: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/breed/${breedName}/images/random`);
  }

  getBreedsWithImages(): Observable<any[]> {
    return this.getAllBreeds().pipe(
      switchMap((response: any) => { // <-- Specify the type of the response
        const breedNames = Object.keys(response.message);
        const breedImages = breedNames.map(name => this.getBreedImage(name));
        return forkJoin(breedImages).pipe(
          map((imageResponses: any[]) => {
            return breedNames.map((name, index) => {
              return {
                name: name,
                image: imageResponses[index].message
              };
            });
          })
        );
      })
    );
  }
}