import { Component, OnInit } from '@angular/core';
import { DogBreedsService } from '../dog-breeds.service';

@Component({
  selector: 'app-dog-breeds',
  templateUrl: './dog-breeds.component.html',
  styleUrls: ['./dog-breeds.component.css']
})
export class DogBreedsComponent implements OnInit {
  breedsWithImages: any[] = [];
  columns: any[][] = [];
  searchTerm: string = '';

  constructor(private dogBreedsService: DogBreedsService) {}

  ngOnInit() {
    this.dogBreedsService.getBreedsWithImages().subscribe((breeds: any[]) => {
      this.breedsWithImages = breeds;
      this.columns = this.chunk(this.breedsWithImages, 4); // <-- Divide the breeds into columns
    });
  }

  private chunk(arr: any[], size: number): any[][] { // <-- Define a helper function to divide the array into columns
    return arr.reduce((acc, _, i) => (i % size ? acc[acc.length - 1].push(arr[i]) : acc.push([arr[i]])) && acc, []);
  }
}