import { BreedFilterPipe } from './breed-filter.pipe';

describe('BreedFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new BreedFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
