import { Pipe, PipeTransform } from '@angular/core';
import { Breed } from './breed';

@Pipe({
  name: 'breedFilter'
})
export class BreedFilterPipe implements PipeTransform {
  transform(breeds: Breed[], searchTerm: string): Breed[] {
    if (!breeds || !searchTerm) {
      return breeds;
    }
    return breeds.filter(breed => breed.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }
}