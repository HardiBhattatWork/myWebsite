
RightNow.Widget.taskMsgDetails=function(data,instanceID){this.data=data;this.instanceID=instanceID;};RightNow.Widget.taskMsgDetails.prototype={};