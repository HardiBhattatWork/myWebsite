/* logout.js */

// APP STORE BUTTON
/*var downloadApp = function () {
   BCM.modal.init(document.getElementById('downloadAppModal'));
};
BCM.addEvent(document.getElementById('downloadApp'), 'click', downloadApp);*/
